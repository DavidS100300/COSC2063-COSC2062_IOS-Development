//
//  Pokemon_AppApp.swift
//  Pokemon App
//

import SwiftUI

@main
struct PokemonApp: App {
    @State private var showWelcome = true
    @StateObject private var vm = PokemonViewModel()
    @AppStorage("isDarkMode") private var isDarkMode = false   // single source of truth

    var body: some Scene {
        WindowGroup {
            ZStack {
                ContentView()
                    .environmentObject(vm)
                    .opacity(showWelcome ? 0 : 1)

                if showWelcome {
                    WelcomeView(isPresented: $showWelcome)
                        .environmentObject(vm)
                        .transition(.move(edge: .trailing))
                }
            }
            .animation(.easeInOut(duration: 0.5), value: showWelcome)
            .preferredColorScheme(isDarkMode ? .dark : .light) // applies instantly
        }
    }
}
