//
//  Pokemon_AppApp.swift
//  Pokemon App
//
//  Created by David Santoso  on 5/8/25.
//

import SwiftUI

@main
struct PokemonApp: App {
    @State private var showWelcome = true
    @StateObject private var vm = PokemonViewModel()

    var body: some Scene {
        WindowGroup {
            ZStack {
                // 1) Your real app UI, but invisible at first
                ContentView()
                  .environmentObject(vm)
                  .opacity(showWelcome ? 0 : 1)
                
                // 2) Your welcome screen on top
                if showWelcome {
                    WelcomeView(isPresented: $showWelcome)
                      .environmentObject(vm)
                      .transition(.move(edge: .trailing))
                }
            }
            // 3) Animate whenever `showWelcome` changes
            .animation(.easeInOut(duration: 0.5), value: showWelcome)
        }
    }
}

