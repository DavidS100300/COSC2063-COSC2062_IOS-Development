//
//  NavigationListView.swift
//  Pokemon App
//
//  Created by David Santoso on 5/8/25.
//

import SwiftUI

struct NavigationListView: View {
    @EnvironmentObject var vm: PokemonViewModel
    @Environment(\.colorScheme) private var scheme
    @State private var searchText = ""
    @State private var showFavoritesOnly = false

    private var filtered: [Pokemon] {
        let q = searchText.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return vm.pokemons.filter { p in
            let matchesName = p.name.lowercased().contains(q)
            let numeric = q.hasPrefix("#") ? String(q.dropFirst()) : q
            let matchesID = Int(numeric) == p.id || String(format: "%03d", p.id).contains(numeric)
            return (!showFavoritesOnly || vm.favorites.contains(p.id)) &&
                   (q.isEmpty || matchesName || matchesID)
        }
    }

    var body: some View {
        NavigationView {
            List(filtered) { p in
                NavigationLink(destination: PokemonDetailView(pokemon: p)) {
                    HStack {
                        Image(p.images.first ?? "")
                            .resizable()
                            .frame(width: 40, height: 40)
                            .cornerRadius(6)

                        VStack(alignment: .leading) {
                            Text(String(format: "#%03d %@", p.id, p.name.capitalized))
                                .font(.headline)
                                .foregroundColor(scheme == .dark ? .white : .primary)
                            Text(p.types.joined(separator: ", "))
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }

                        Spacer()

                        Button {
                            vm.toggleFavorite(p.id)
                        } label: {
                            Image(systemName: vm.favorites.contains(p.id) ? "heart.fill" : "heart")
                                .foregroundColor(vm.favorites.contains(p.id) ? .red : (scheme == .dark ? .white : .primary))
                                .font(.system(size: 18))
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(.vertical, 4)
                }
            }
            .listStyle(PlainListStyle())
            .background(scheme == .dark ? Color(.darkGray) : Color(.systemBackground))
            .navigationTitle("All Pokémon")
            .searchable(text: $searchText, prompt: "Search by name or ID")
            .toolbar {
                // ⭐️ Move star to TOP-LEFT
                ToolbarItem(placement: .navigationBarLeading) {
                    Button {
                        showFavoritesOnly.toggle()
                    } label: {
                        Image(systemName: showFavoritesOnly ? "star.fill" : "star")
                            .imageScale(.large)
                            .symbolRenderingMode(.hierarchical)
                            .foregroundStyle(showFavoritesOnly ? .blue : .primary)
                            .accessibilityLabel("Show favorites only")
                    }
                }

                // 
                ToolbarItem(placement: .navigationBarTrailing) {
                    ThemeToggle()
                }
            }
        }
    }
}

struct NavigationListView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationListView()
            .environmentObject(PokemonViewModel())
            .preferredColorScheme(.dark)
    }
}
