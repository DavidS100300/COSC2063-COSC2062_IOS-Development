//
//  NavigationListView.swift
//  Pokemon App
//
//  Created by David Santoso on 5/8/25.
//

import SwiftUI

struct NavigationListView: View {
    @EnvironmentObject var vm: PokemonViewModel

    @State private var searchText = ""
    @State private var showFavoritesOnly = false

    // Filtered by searchText & favorites toggle
    private var filtered: [Pokemon] {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        let lower = query.lowercased()

        return vm.pokemons.filter { p in
            // 1) Favorites toggle
            guard !showFavoritesOnly || vm.favorites.contains(p.id) else {
                return false
            }

            // 2) If the query is empty, show everything
            guard !lower.isEmpty else {
                return true
            }

            // 3) Match by name
            if p.name.lowercased().contains(lower) {
                return true
            }

            // 4) Match by numeric ID (e.g. "1", "001", "#1", "#001")
            // Strip any leading "#"
            let numericPart = lower.hasPrefix("#") ? String(lower.dropFirst()) : lower

            if let qId = Int(numericPart), qId == p.id {
                return true
            }

            return false
        }
    }

    var body: some View {
        NavigationView {
            List(filtered) { p in
                NavigationLink(destination: PokemonDetailView(pokemon: p)) {
                    HStack {
                        Image(p.images.first ?? "")
                            .resizable()
                            .frame(width: 40, height: 40)
                            .cornerRadius(6)

                        VStack(alignment: .leading) {
                            Text(String(format: "#%03d %@", p.id, p.name.capitalized))
                                .font(.headline)
                            Text(p.types.joined(separator: ", "))
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }

                        Spacer()

                        Button {
                            vm.toggleFavorite(p.id)
                        } label: {
                            Image(systemName: vm.favorites.contains(p.id) ? "heart.fill" : "heart")
                                .foregroundColor(vm.favorites.contains(p.id) ? .red : .gray)
                                .font(.system(size: 18))
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(.vertical, 4)
                }
            }
            .listStyle(PlainListStyle())
            .navigationTitle("All Pokémon")
            .toolbar {
                Toggle(isOn: $showFavoritesOnly) {
                    Image(systemName: "star.fill")
                }
            }
        }
        // ← Apply searchable to the NavigationView:
        .searchable(
            text: $searchText,
            placement: .navigationBarDrawer(displayMode: .always),
            prompt: "Search Pokémon"
        )
        .textInputAutocapitalization(.none)
        .disableAutocorrection(true)
    }
}

struct NavigationListView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationListView()
            .environmentObject(PokemonViewModel())
    }
}
