//
//  ThemePreference.swift
//  Pokemon App
//
//  Created by David Santoso  on 8/8/25.
//


import SwiftUI

enum ThemePreference: String, CaseIterable {
    case system
    case light
    case dark

    var iconName: String {
        switch self {
        case .system: return "circle.lefthalf.fill" // system
        case .light:  return "sun.max.fill"
        case .dark:   return "moon.fill"
        }
    }

    var label: String {
        switch self {
        case .system: return "System"
        case .light:  return "Light"
        case .dark:   return "Dark"
        }
    }

    var colorSchemeOverride: ColorScheme? {
        switch self {
        case .system: return nil         // ← follow phone theme
        case .light:  return .light
        case .dark:   return .dark
        }
    }
}
