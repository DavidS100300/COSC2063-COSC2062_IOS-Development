//
//  PokemonType.swift
//  Pokemon App
//
//  Created by David Santoso  on 5/8/25.
//


import Foundation


enum PokemonType: Int, CaseIterable {
    case normal   = 1
    case fire     = 2
    case water    = 3
    case grass    = 4
    case electric = 5
    case ice      = 6
    case fighting = 7
    case poison   = 8
    case ground   = 9
    case flying   = 10
    case psychic  = 11
    case bug      = 12
    case rock     = 13
    case ghost    = 14
    case dragon   = 15
    case dark     = 16
    case steel    = 17
    case fairy    = 18
    
    // → later: just add `case psychic = 7`, etc.

    var displayName: String {
        switch self {
        case .fire:     return "Fire"
        case .water:    return "Water"
        case .grass:    return "Grass"
        case .electric: return "Electric"
        case .flying:   return "Flying"
        case .dragon:   return "Dragon"
        case .bug:      return "Bug"
        case .dark:     return "Dark"
        case .fairy:    return "Fairy"
        case .fighting: return "Fighting"
        case .ghost:    return "Ghost"
        case .ground:   return "Ground"
        case .ice:      return "Ice"
        case .normal:   return "Normal"
        case .poison:   return "Poison"
        case .psychic:  return "Psychic"
        case .rock:     return "Rock"
        case .steel:    return "Steel"
        }
    }
}
