// PokemonType.swift
// Pokemon App
// Created by David Santoso on 5/8/25.

import SwiftUI

enum PokemonType: Int, CaseIterable, Codable {
    case normal   = 1
    case fire     = 2
    case water    = 3
    case grass    = 4
    case electric = 5
    case ice      = 6
    case fighting = 7
    case poison   = 8
    case ground   = 9
    case flying   = 10
    case psychic  = 11
    case bug      = 12
    case rock     = 13
    case ghost    = 14
    case dragon   = 15
    case dark     = 16
    case steel    = 17
    case fairy    = 18
    
    var displayName: String {
        switch self {
        case .fire:     return "Fire"
        case .water:    return "Water"
        case .grass:    return "Grass"
        case .electric: return "Electric"
        case .flying:   return "Flying"
        case .dragon:   return "Dragon"
        case .bug:      return "Bug"
        case .dark:     return "Dark"
        case .fairy:    return "Fairy"
        case .fighting: return "Fighting"
        case .ghost:    return "Ghost"
        case .ground:   return "Ground"
        case .ice:      return "Ice"
        case .normal:   return "Normal"
        case .poison:   return "Poison"
        case .psychic:  return "Psychic"
        case .rock:     return "Rock"
        case .steel:    return "Steel"
        }
    }
    private struct Palette { let light: Color; let dark: Color }
    
    private var palette: Palette {
           switch self {
           case .fire:     return .init(light: .orange,                    dark: Color.orange.opacity(0.6))
           case .water:    return .init(light: Color.blue.opacity(0.5),    dark: Color.blue.opacity(0.35))
           case .grass:    return .init(light: Color.green.opacity(0.5),   dark: Color.green.opacity(0.35))
           case .electric: return .init(light: Color.yellow.opacity(0.5),  dark: Color.yellow.opacity(0.35))
           case .bug:      return .init(light: Color.green.opacity(0.7),   dark: Color.green.opacity(0.45))
           case .flying:   return .init(light: Color.cyan.opacity(0.5),    dark: Color.cyan.opacity(0.35))
           case .poison:   return .init(light: Color.purple.opacity(0.5),  dark: Color.purple.opacity(0.35))
           case .dragon:   return .init(light: Color.indigo.opacity(0.5),  dark: Color.indigo.opacity(0.35))
           case .psychic:  return .init(light: Color.purple.opacity(0.7),  dark: Color.purple.opacity(0.45))
           case .dark:     return .init(light: .black,                     dark: Color(hue: 0, saturation: 0, brightness: 0.2)) // deep gray in dark mode
           case .ground:   return .init(light: .brown,                     dark: Color.brown.opacity(0.6))
           case .ice:      return .init(light: .blue,                      dark: Color.blue.opacity(0.5))
           case .normal:   return .init(light: .gray,                      dark: Color.gray.opacity(0.6))
           case .rock:     return .init(light: .gray,                      dark: Color.gray.opacity(0.6))
           case .steel:    return .init(light: .gray,                      dark: Color.gray.opacity(0.6))
           case .fairy:    return .init(light: .pink,                      dark: Color.pink.opacity(0.6))
           case .fighting: return .init(light: .red,                       dark: Color.red.opacity(0.6))
           case .ghost:    return .init(light: .gray,                      dark: Color.gray.opacity(0.6))
           }
       }
    
    func color(for scheme: ColorScheme) -> Color {
        scheme == .dark ? palette.dark : palette.light
    }
    static func from(displayName: String) -> PokemonType? {
        allCases.first { $0.displayName.caseInsensitiveCompare(displayName) == .orderedSame }
    }
}
