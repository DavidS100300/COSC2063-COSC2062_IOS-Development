// PokemonViewModel.swift
// Pokemon App
// Created by David Santoso on 5/8/25.

import SwiftUI

class PokemonViewModel: ObservableObject {
    @Published var pokemons: [Pokemon] = [
        // Bulbasaur: Pallet Town (example coords)
        Pokemon(
            id: 1,
            name: "Bulbasaur",
            types: ["Grass","Poison"],
            images: ["bulbasaur"],
            description: "For some time after its birth, it uses the nutrients that are packed into the seed on its back in order to grow.",
            location: Location(latitude: 10.72991265, longitude: 106.693208239997),
            stats: Stats(hp: 45, attack: 49, defense: 49, speed: 45, special: 65, special_defense: 50)

        ),

        // Ivysaur: Viridian City
        Pokemon(
            id: 2,
            name: "Ivysaur",
            types: ["Grass","Poison"],
            images: ["ivysaur"],
            description: "The more sunlight Ivysaur bathes in, the more strength wells up within it, allowing the bud on its back to grow larger.",
            location: Location(latitude: 34.2, longitude: 139.1),
            stats: Stats(hp: 45, attack: 49, defense: 49, speed: 45, special: 65, special_defense: 50)

        ),

        // Venusaur: Celadon City
        Pokemon(
            id: 3,
            name: "Venusaur",
            types: ["Grass","Poison"],
            images: ["venusaur"],
            description: "While it basks in the sun, it can convert the light into energy. As a result, it is more powerful in the summertime.",
            location: Location(latitude: 34.3, longitude: 139.0),
            stats: Stats(hp: 45, attack: 49, defense: 49, speed: 45, special: 65, special_defense: 50)

        ),

        // Charmander: Mt. Ember
        Pokemon(
            id: 4,
            name: "Charmander",
            types: ["Fire"],
            images: ["charmander"],
            description: "The flame on its tail shows the strength of its life-force. If Charmander is weak, the flame also burns weakly.",
            location: Location(latitude: 35.0, longitude: 139.7),
            stats: Stats(hp: 45, attack: 49, defense: 49, speed: 45, special: 65, special_defense: 50)

        ),

        // Charmeleon: Route 3
        Pokemon(
            id: 5,
            name: "Charmeleon",
            types: ["Fire"],
            images: ["charmeleon"],
            description: "When it swings its burning tail, the temperature around it rises higher and higher, tormenting its opponents.",
            location: Location(latitude: 35.1, longitude: 139.8),
            stats: Stats(hp: 45, attack: 49, defense: 49, speed: 45, special: 65, special_defense: 50)

        ),

        // Charizard: Victory Road
        Pokemon(
            id: 6,
            name: "Charizard",
            types: ["Fire","Flying"],
            images: ["charizard"],
            description: "If Charizard becomes truly angered, the flame at the tip of its tail burns in a light blue shade.",
            location: Location(latitude: 35.2, longitude: 139.7),
            stats: Stats(hp: 45, attack: 49, defense: 49, speed: 45, special: 65, special_defense: 50)

        ),

        // Squirtle: Cerulean City
        Pokemon(
            id: 7,
            name: "Squirtle",
            types: ["Water"],
            images: ["squirtle"],
            description: "After birth, its back swells and hardens into a shell. It sprays a potent foam from its mouth.",
            location: Location(latitude: 34.1, longitude: 139.2),
            stats: Stats(hp: 45, attack: 49, defense: 49, speed: 45, special: 65, special_defense: 50)

        ),

        // Wartortle: Mt. Moon (cannot be captured in this example)
        Pokemon(
            id: 8,
            name: "Wartortle",
            types: ["Water"],
            images: ["wartortle"],
            description: "Wartortle’s long, furry tail is a symbol of longevity.",
            location: nil,
            stats: Stats(hp: 45, attack: 49, defense: 49, speed: 45, special: 65, special_defense: 50)

        ),

        // Blastoise: Cerulean Cave
        Pokemon(
            id: 9,
            name: "Blastoise",
            types: ["Water"],
            images: ["blastoise"],
            description: "It deliberately increases its body weight so it can withstand the recoil of the water jets it fires.",
            location: Location(latitude: 34.15, longitude: 139.25),
            stats: Stats(hp: 45, attack: 49, defense: 49, speed: 45, special: 65, special_defense: 50)

        ),

        // Caterpie: Route 2
        Pokemon(
            id: 10,
            name: "Caterpie",
            types: ["Bug"],
            images: ["caterpie"],
            description: "For protection, it releases a horrible stench from the antenna on its head to drive away enemies.",
            location: Location(latitude: 34.05, longitude: 139.1),
            stats: Stats(hp: 45, attack: 49, defense: 49, speed: 45, special: 65, special_defense: 50)

        ),

        // Metapod: Rusturf Tunnel (cannot be captured in this example)
        Pokemon(
            id: 11,
            name: "Metapod",
            types: ["Bug"],
            images: ["metapod"],
            description: "It is waiting for the moment to evolve.",
            location: nil,
            stats: Stats(hp: 45, attack: 49, defense: 49, speed: 45, special: 65, special_defense: 50)

        ),

        // Butterfree: West of Cerulean City
        Pokemon(
            id: 12,
            name: "Butterfree",
            types: ["Bug","Flying"],
            images: ["butterfree"],
            description: "It loves the nectar of flowers and can locate flower patches.",
            location: Location(latitude: 34.12, longitude: 139.22),
            stats: Stats(hp: 45, attack: 49, defense: 49, speed: 45, special: 65, special_defense: 50)

        )
    ]

    @Published var favorites: Set<Int> = []

    func toggleFavorite(_ id: Int) {
        if favorites.contains(id) {
            favorites.remove(id)
        } else {
            favorites.insert(id)
        }
    }
}
