// PokemonViewModel.swift
// Pokemon App

import SwiftUI

class PokemonViewModel: ObservableObject {
    @Published var pokemons: [Pokemon] = []
    @Published var favorites: Set<Int> = []
    

    private let favoritesKey = "favorites"

    init() {
        loadPokemons()
        loadFavorites()
    }

    // MARK: - Load pokemons from pokemons.json (bundle), fall back to stub if missing/invalid
    private func loadPokemons() {
        if let url = Bundle.main.url(forResource: "Pokemon", withExtension: "json") {
            do {
                let data = try Data(contentsOf: url)
                let decoded = try JSONDecoder().decode([Pokemon].self, from: data)
                self.pokemons = decoded
                return
            } catch {
                print("❌ JSON decode failed → using stub. Error:", error)
            }
        } else {
            print("❌ pokemons.json not found → using stub.")
        }
    }

    // MARK: - Favorites persistence
    private func loadFavorites() {
        if let saved = UserDefaults.standard.array(forKey: favoritesKey) as? [Int] {
            favorites = Set(saved)
        }
    }

    private func saveFavorites() {
        UserDefaults.standard.set(Array(favorites), forKey: favoritesKey)
    }

    func toggleFavorite(_ id: Int) {
        if favorites.contains(id) { favorites.remove(id) } else { favorites.insert(id) }
        saveFavorites()
    }
}
