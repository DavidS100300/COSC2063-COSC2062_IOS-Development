//
//  PokemonDetailView.swift
//  Pokemon App
//
//  Created by David Santoso on 5/8/25.
//

import SwiftUI
import MapKit

struct PokemonDetailView: View {
    @EnvironmentObject var vm: PokemonViewModel
    @Environment(\.presentationMode) private var presentationMode
    let pokemon: Pokemon

    // MARK: – Colors (customize these later)
    private let statsCardBackground = Color(.secondarySystemBackground)
    private let statsCardBorder     = Color.gray.opacity(0.3)
    private let hpColor             = Color.red.opacity(0.2)
    private let atkColor            = Color.orange.opacity(0.2)
    private let defColor            = Color.yellow.opacity(0.2)
    private let spAtkColor          = Color.blue.opacity(0.2)
    private let speedColor          = Color.pink.opacity(0.2)
    private let spDefColor          = Color.green.opacity(0.2)

    // MARK: – Map region
    @State private var region: MKCoordinateRegion
    private let initialRegion: MKCoordinateRegion

    init(pokemon: Pokemon) {
        self.pokemon = pokemon

        if let loc = pokemon.location {
            let centered = MKCoordinateRegion(
                center: CLLocationCoordinate2D(latitude: loc.latitude,
                                               longitude: loc.longitude),
                span: MKCoordinateSpan(latitudeDelta: 0.005,
                                       longitudeDelta: 0.005)
            )
            _region = State(initialValue: centered)
            initialRegion = centered
        } else {
            let fallback = MKCoordinateRegion(
                center: CLLocationCoordinate2D(latitude: 0, longitude: 0),
                span: MKCoordinateSpan(latitudeDelta: 180, longitudeDelta: 360)
            )
            _region = State(initialValue: fallback)
            initialRegion = fallback
        }
    }

    private var isFavorite: Bool {
        vm.favorites.contains(pokemon.id)
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                // MARK: – Photo
                Image(pokemon.images.first!)
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(12)
                    .padding(.horizontal)

                // MARK: – ID, Name & Favorite Button
                HStack {
                    Text(String(format: "#%03d %@", pokemon.id, pokemon.name))
                        .font(.largeTitle.bold())
                    Spacer()
                    Button {
                        vm.toggleFavorite(pokemon.id)
                    } label: {
                        Image(systemName: isFavorite ? "heart.fill" : "heart")
                            .font(.title2)
                            .foregroundColor(isFavorite ? .red : .gray)
                    }
                    .buttonStyle(.plain)
                }
                .padding(.horizontal)

                Divider().padding(.horizontal)

                // MARK: – About Section
                Text("About \(pokemon.name)")
                    .font(.title2.bold())
                    .padding(.horizontal)
                Text(pokemon.description)
                    .font(.body)
                    .padding(.horizontal)

                Divider().padding(.horizontal)

                // MARK: – Stats Section
                let totalPoints = pokemon.stats.hp
                               + pokemon.stats.attack
                               + pokemon.stats.defense
                               + pokemon.stats.speed
                               + pokemon.stats.special

                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Text("Stats")
                            .font(.title2.bold())
                        Spacer()
                        Text("Total: \(totalPoints)")
                            .font(.subheadline)
                    }

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            StatsBox(
                                value: pokemon.stats.hp,
                                label: "HP",
                                backgroundColor: hpColor
                            )
                            StatsBox(
                                value: pokemon.stats.attack,
                                label: "Atk",
                                backgroundColor: atkColor
                            )
                            StatsBox(
                                value: pokemon.stats.defense,
                                label: "Def",
                                backgroundColor: defColor
                            )
                            StatsBox(
                                value: pokemon.stats.special,
                                label: "Sp.Atk",
                                backgroundColor: spAtkColor
                            )
                            StatsBox(
                                value: pokemon.stats.speed,
                                label: "Speed",
                                backgroundColor: speedColor
                            )
                            StatsBox(
                                value: pokemon.stats.special_defense,
                                label: "Sp.Def",
                                backgroundColor: spDefColor
                            )
                        }
                        .padding(.vertical, 4)
                    }
                }
                .padding()
                .background(statsCardBackground)
                .cornerRadius(12)
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(statsCardBorder, lineWidth: 1)
                )
                .padding(.horizontal)

                Divider().padding(.horizontal)

                // MARK: – Location Map
                Text("Location")
                    .font(.title2.bold())
                    .padding(.horizontal)

                Map(
                    coordinateRegion: $region,
                    annotationItems: pokemon.location != nil ? [pokemon] : []
                ) { p in
                    MapMarker(
                        coordinate: CLLocationCoordinate2D(
                            latitude: p.location!.latitude,
                            longitude: p.location!.longitude
                        ),
                        tint: .red
                    )
                }
                .frame(height: 300)
                .cornerRadius(12)
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(Color.gray, lineWidth: 1)
                )
                .padding(.horizontal)

                // MARK: – Recenter Button
                if pokemon.location != nil {
                    Button("Recenter to Pin") {
                        withAnimation(.easeInOut) {
                            region = initialRegion
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .padding(.horizontal)
                }

                // MARK: – Cannot be captured badge
                if pokemon.location == nil {
                    Text("Cannot be captured")
                        .font(.headline)
                        .foregroundColor(.secondary)
                        .padding(.vertical, 6)
                        .padding(.horizontal, 12)
                        .background(Color(.systemGray5))
                        .cornerRadius(8)
                        .frame(maxWidth: .infinity)
                        .padding(.horizontal)
                }
            }
            .padding(.vertical)
        }
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button {
                    presentationMode.wrappedValue.dismiss()
                } label: {
                    Image(systemName: "chevron.left")
                        .font(.title2)
                        .foregroundColor(.primary)
                }
            }
        }
    }
}

// MARK: – StatsBox Helper

struct StatsBox: View {
    let value: Int
    let label: String
    var backgroundColor: Color = Color.gray.opacity(0.2)

    var body: some View {
        VStack(spacing: 2) {
            Text("\(value)")
                .font(.headline)
            Text(label)
                .font(.caption2)
        }
        .frame(width: 50, height: 60)
        .background(backgroundColor)
        .cornerRadius(8)
    }
}

struct PokemonDetailView_Previews: PreviewProvider {
    static let vm = PokemonViewModel()
    static var previews: some View {
        NavigationView {
            PokemonDetailView(pokemon: vm.pokemons[0])
                .environmentObject(vm)
        }
    }
}
