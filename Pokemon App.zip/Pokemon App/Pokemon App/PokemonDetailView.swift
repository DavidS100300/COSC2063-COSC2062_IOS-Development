import SwiftUI
import MapKit

struct PokemonDetailView: View {
    @EnvironmentObject var vm: PokemonViewModel
    @Environment(\.presentationMode) private var presentationMode
    @Environment(\.colorScheme) private var scheme
    let pokemon: Pokemon

    private var typeColor: Color {
        guard
            let firstName = pokemon.types.first,
            let typeEnum = PokemonType.from(displayName: firstName)
        else { return Color(.systemBackground) }
        return typeEnum.color(for: scheme)
    }

    private let statsCardBackground = Color(.secondarySystemBackground)
    private let statsCardBorder     = Color.primary.opacity(0.08)
    private let hpColor             = Color.red.opacity(0.20)
    private let atkColor            = Color.orange.opacity(0.20)
    private let defColor            = Color.yellow.opacity(0.20)
    private let spAtkColor          = Color.blue.opacity(0.20)
    private let speedColor          = Color.pink.opacity(0.20)
    private let spDefColor          = Color.green.opacity(0.20)

    @State private var region: MKCoordinateRegion
    private let initialRegion: MKCoordinateRegion

    init(pokemon: Pokemon) {
        self.pokemon = pokemon
        if let loc = pokemon.location {
            let centered = MKCoordinateRegion(
                center: CLLocationCoordinate2D(latitude: loc.latitude, longitude: loc.longitude),
                span: MKCoordinateSpan(latitudeDelta: 0.005, longitudeDelta: 0.005)
            )
            _region = State(initialValue: centered)
            initialRegion = centered
        } else {
            let fallback = MKCoordinateRegion(
                center: CLLocationCoordinate2D(latitude: 0, longitude: 0),
                span: MKCoordinateSpan(latitudeDelta: 180, longitudeDelta: 360)
            )
            _region = State(initialValue: fallback)
            initialRegion = fallback
        }
    }

    private var isFavorite: Bool { vm.favorites.contains(pokemon.id) }

    private var galleryImages: [String] {
        if !pokemon.images.isEmpty { return pokemon.images }
        let base = pokemon.name.lowercased()
        return [base, "\(base)1", "\(base)2"]
    }

    var body: some View {
        ZStack {
            typeColor.ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    // Main Image
                    ZStack {
                        RoundedRectangle(cornerRadius: 12)
                            .fill(scheme == .dark ? Color(.darkGray) : Color(.systemBackground))
                            .shadow(radius: 2, y: 1)

                        Image(pokemon.images.first ?? "")
                            .resizable()
                            .scaledToFit()
                            .padding(12)
                    }
                    .frame(height: 260)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color.primary.opacity(0.10), lineWidth: 1)
                    )
                    .padding(.horizontal)

                    // Name & Favorite
                    HStack {
                        Text(String(format: "#%03d %@", pokemon.id, pokemon.name))
                            .font(.largeTitle.bold())
                            .foregroundColor(scheme == .dark ? .white : .primary)
                        Spacer()
                        Button {
                            vm.toggleFavorite(pokemon.id)
                        } label: {
                            Image(systemName: isFavorite ? "heart.fill" : "heart")
                                .font(.title2)
                                .foregroundColor(isFavorite ? .red : (scheme == .dark ? .white : .secondary))
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(.horizontal)

                    Divider().padding(.horizontal)

                    Text("About \(pokemon.name)")
                        .font(.title2.bold())
                        .foregroundColor(scheme == .dark ? .white : .primary)
                        .padding(.horizontal)

                    Text(pokemon.description)
                        .font(.body)
                        .foregroundColor(scheme == .dark ? .white : .primary)
                        .padding(.horizontal)

                    Divider().padding(.horizontal)

                    // Stats
                    let totalPoints = pokemon.stats.hp
                                     + pokemon.stats.attack
                                     + pokemon.stats.defense
                                     + pokemon.stats.speed
                                     + pokemon.stats.special

                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text("Stats")
                                .font(.title2.bold())
                                .foregroundColor(scheme == .dark ? .white : .primary)
                            Spacer()
                            Text("Total: \(totalPoints)")
                                .font(.subheadline)
                                .foregroundColor(scheme == .dark ? .white : .secondary)
                        }

                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 12) {
                                StatsBox(value: pokemon.stats.hp,              label: "HP",     backgroundColor: hpColor)
                                StatsBox(value: pokemon.stats.attack,          label: "Atk",    backgroundColor: atkColor)
                                StatsBox(value: pokemon.stats.defense,         label: "Def",    backgroundColor: defColor)
                                StatsBox(value: pokemon.stats.special,         label: "Sp.Atk", backgroundColor: spAtkColor)
                                StatsBox(value: pokemon.stats.speed,           label: "Speed",  backgroundColor: speedColor)
                                StatsBox(value: pokemon.stats.special_defense, label: "Sp.Def", backgroundColor: spDefColor)
                            }
                            .padding(.vertical, 4)
                        }
                    }
                    .padding()
                    .background(scheme == .dark ? Color(.darkGray) : statsCardBackground)
                    .cornerRadius(12)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(statsCardBorder, lineWidth: 1)
                    )
                    .padding(.horizontal)

                    // Battle Power
                    Text("Battle Power")
                        .font(.title2.bold())
                        .foregroundColor(scheme == .dark ? .white : .primary)
                        .padding(.horizontal)

                    IconRatingView(
                        value: pokemon.battlePower,
                        maxRating: 5,
                        filledImage: "flame.fill",
                        emptyImage: "flame",
                        filledColor: .red
                    )
                    .frame(height: 24)
                    .padding(.horizontal)

                    // Rating
                    Text("Rating")
                        .font(.title2.bold())
                        .foregroundColor(scheme == .dark ? .white : .primary)
                        .padding(.horizontal)

                    IconRatingView(
                        value: pokemon.rating,
                        maxRating: 5,
                        filledImage: "star.fill",
                        emptyImage: "star",
                        filledColor: .yellow
                    )
                    .frame(height: 24)
                    .padding(.horizontal)

                    Divider().padding(.horizontal)

                    // Gallery
                    Text("Gallery")
                        .font(.title2.bold())
                        .foregroundColor(scheme == .dark ? .white : .primary)
                        .padding(.horizontal)

                    TabView {
                        ForEach(galleryImages, id: \.self) { img in
                            ZStack {
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(scheme == .dark ? Color(.darkGray) : Color(.systemBackground))
                                    .shadow(radius: 2, y: 1)

                                Image(img)
                                    .resizable()
                                    .scaledToFit()
                                    .padding(12)
                            }
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(Color.primary.opacity(0.10), lineWidth: 1)
                            )
                            .padding(.horizontal)
                        }
                    }
                    .frame(height: 240)
                    .tabViewStyle(PageTabViewStyle(indexDisplayMode: .automatic))
                    .padding(.bottom, 8)

                    Divider().padding(.horizontal)

                    // Map
                    Text("Location")
                        .font(.title2.bold())
                        .foregroundColor(scheme == .dark ? .white : .primary)
                        .padding(.horizontal)

                    Map(
                        coordinateRegion: $region,
                        annotationItems: pokemon.location != nil ? [pokemon] : []
                    ) { p in
                        MapMarker(
                            coordinate: CLLocationCoordinate2D(
                                latitude: p.location!.latitude,
                                longitude: p.location!.longitude
                            ),
                            tint: .red
                        )
                    }
                    .frame(height: 300)
                    .cornerRadius(12)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color.primary.opacity(0.10), lineWidth: 1)
                    )
                    .padding(.horizontal)

                    if pokemon.location != nil {
                        Button("Recenter to Pin") {
                            withAnimation(.easeInOut) { region = initialRegion }
                        }
                        .buttonStyle(.borderedProminent)
                        .padding(.horizontal)
                    } else {
                        Text("Cannot be captured")
                            .font(.headline)
                            .foregroundColor(.secondary)
                            .padding(.vertical, 6)
                            .padding(.horizontal, 12)
                            .background(scheme == .dark ? Color(.darkGray) : Color(.secondarySystemBackground))
                            .cornerRadius(8)
                            .frame(maxWidth: .infinity)
                            .padding(.horizontal)
                    }
                }
                .padding(.vertical)
            }
        }
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button { presentationMode.wrappedValue.dismiss() } label: {
                    Image(systemName: "chevron.left")
                        .font(.title2)
                        .foregroundColor(.primary)
                }
            }
            ToolbarItem(placement: .navigationBarTrailing) {
                ThemeToggle()
            }
        }
    }
}

struct StatsBox: View {
    let value: Int
    let label: String
    var backgroundColor: Color = Color.gray.opacity(0.2)

    var body: some View {
        VStack(spacing: 4) {
            Text("\(value)").font(.headline)
            Text(label).font(.caption2)
        }
        .frame(width: 56, height: 64)
        .background(backgroundColor)
        .cornerRadius(8)
    }
}

struct PokemonDetailView_Previews: PreviewProvider {
    static let vm = PokemonViewModel()
    static var previews: some View {
        NavigationView {
            PokemonDetailView(pokemon: vm.pokemons[0])
                .environmentObject(vm)
                .preferredColorScheme(.dark)
        }
    }
}
