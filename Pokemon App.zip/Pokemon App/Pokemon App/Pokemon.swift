// Pokemon.swift
// Pokemon App
// Created by David Santoso on 5/8/25.

import Foundation

struct Location: Codable {
    let latitude: Double
    let longitude: Double
}

struct Pokemon: Identifiable, Codable {
    let id: Int
    let name: String
    let types: [String]
    let images: [String]
    let description: String
    let location: Location?
    let stats: Stats
    let battlePower: Double
    let rating: Double

}

struct Stats: Codable {
    let hp: Int
    let attack: Int
    let defense: Int
    let speed: Int
    let special: Int
    let special_defense:Int
}
