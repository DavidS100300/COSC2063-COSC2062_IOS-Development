//
//  ContentView.swift
//  Pokemon App
//
//  Created by David Santoso  on 5/8/25.
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var vm: PokemonViewModel   // ← pick up the VM

    var body: some View {
        TabView {
            HomePage()
                .tabItem {
                    Label("Home", systemImage: "house.fill")
                }

            NavigationListView()
                .tabItem {
                    Label("List", systemImage: "list.bullet")
                }
        }
    }
}

#Preview {
    ContentView()
        .environmentObject(PokemonViewModel())
}
