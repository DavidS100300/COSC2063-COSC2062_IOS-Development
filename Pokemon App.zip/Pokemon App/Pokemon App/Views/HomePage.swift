//
//  HomePage.swift
//  Pokemon App
//
//  Created by David Santoso  on 5/8/25.
//

import SwiftUI

struct HomePage: View {
    @EnvironmentObject var vm: PokemonViewModel
    @Environment(\.colorScheme) private var scheme

    // Top 5 featured Pokémon
    private var featured: [Pokemon] {
        Array(vm.pokemons.prefix(5))
    }

    // Build categories: Favorites + only types present in data, ordered by ID
    private var categories: [String] {
        let availableTypes = PokemonType.allCases.filter { pType in
            vm.pokemons.contains { pokemon in
                pokemon.types.contains(pType.displayName)
            }
        }
        let typeNames = availableTypes
            .sorted { $0.rawValue < $1.rawValue }
            .map(\.displayName)

        return ["Favorites"] + typeNames
    }

    var body: some View {
        NavigationView {
            ScrollView {
                // MARK: - Featured Slider
                TabView {
                    ForEach(featured.shuffled()) { p in
                        NavigationLink(destination: PokemonDetailView(pokemon: p)) {
                            Image(p.images.first ?? "")
                                .resizable()
                                .scaledToFill()
                                .frame(height: 400)
                                .clipped()
                        }
                        .buttonStyle(.plain)
                    }
                }
                .frame(height: 400)
                .tabViewStyle(PageTabViewStyle())

                // MARK: - Categories
                ForEach(categories, id: \.self) { cat in
                    VStack(alignment: .leading, spacing: 8) {
                        Text(cat)
                            .font(.title2.bold())
                            .padding(.horizontal)
                            .foregroundColor(scheme == .dark ? .white : .primary)

                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 16) {
                                ForEach(vm.pokemons.filter {
                                    cat == "Favorites"
                                        ? vm.favorites.contains($0.id)
                                        : $0.types.contains(cat)
                                }) { p in
                                    NavigationLink(destination: PokemonDetailView(pokemon: p)) {
                                        CardView(pokemon: p)
                                            .frame(width: 140)
                                    }
                                }
                            }
                            .padding(.horizontal)
                        }
                    }
                    .padding(.vertical, 8)
                }
            }
            .background(scheme == .dark ? Color(.darkGray) : Color(.systemBackground))
            .navigationTitle("Home")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    ThemeToggle() // 🌙/☀️ toggle
                }
            }
        }
    }
}

// MARK: - CardView with Favorite Button
struct CardView: View {
    @EnvironmentObject private var vm: PokemonViewModel
    @Environment(\.colorScheme) private var scheme
    let pokemon: Pokemon

    private var isFavorite: Bool {
        vm.favorites.contains(pokemon.id)
    }

    var body: some View {
        ZStack(alignment: .topTrailing) {
            VStack(spacing: 8) {
                Image(pokemon.images.first ?? "")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(8)
                    .frame(height: 100)

                Text(pokemon.name)
                    .font(.headline)
                    .lineLimit(1)
                    .foregroundColor(scheme == .dark ? .white : .primary)
            }
            .padding(8)
            .background(scheme == .dark ? Color(.darkGray) : Color(.systemBackground))
            .cornerRadius(12)
            .shadow(radius: 3)

            Button {
                vm.toggleFavorite(pokemon.id)
            } label: {
                Image(systemName: isFavorite ? "heart.fill" : "heart")
                    .font(.system(size: 16))
                    .foregroundColor(isFavorite ? .red : (scheme == .dark ? .white : .primary))
                    .padding(6)
                    .background(scheme == .dark ? Color(.systemGray4) : Color(.secondarySystemBackground))
                    .clipShape(Circle())
            }
            .offset(x: -8, y: 8)
        }
    }
}

struct HomePage_Previews: PreviewProvider {
    static var previews: some View {
        HomePage()
            .environmentObject(PokemonViewModel())
            .preferredColorScheme(.dark) // preview dark
    }
}
