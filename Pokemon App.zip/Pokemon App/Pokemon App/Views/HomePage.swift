//
//  HomePage.swift
//  Pokemon App
//
//  Created by David Santoso  on 5/8/25.
//

import SwiftUI

struct HomePage: View {
    @EnvironmentObject var vm: PokemonViewModel

    private var featured: [Pokemon] {
        Array(vm.pokemons.prefix(5))
    }

    // Favorites + only types that exist in current data, ordered by enum rawValue
    private var categories: [String] {
        let availableTypes = PokemonType.allCases.filter { type in
            vm.pokemons.contains { $0.types.contains(type.displayName) }
        }
        return ["Favorites"] + availableTypes.sorted { $0.rawValue < $1.rawValue }
                                            .map(\.displayName)
    }

    var body: some View {
        NavigationView {
            ScrollView {
                // Featured slider (clickable)
                TabView {
                    ForEach(featured.shuffled()) { p in
                        NavigationLink(destination: PokemonDetailView(pokemon: p)) {
                            Image(p.images.first ?? "")
                                .resizable()
                                .scaledToFill()
                                .frame(height: 200)
                                .clipped()
                                .overlay(alignment: .bottomLeading) {
                                    Text(p.name)
                                        .font(.title2.bold())
                                        .padding(8)
                                        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 8))
                                        .padding(8)
                                }
                        }
                    }
                }
                .frame(height: 200)
                .tabViewStyle(PageTabViewStyle(indexDisplayMode: .automatic))

                // Categories
                ForEach(categories, id: \.self) { cat in
                    VStack(alignment: .leading, spacing: 8) {
                        Text(cat)
                            .font(.title2.bold())
                            .padding(.horizontal)

                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 16) {
                                ForEach(vm.pokemons.filter {
                                    cat == "Favorites"
                                        ? vm.favorites.contains($0.id)
                                        : $0.types.contains(cat)
                                }) { p in
                                    NavigationLink(destination: PokemonDetailView(pokemon: p)) {
                                        CardView(pokemon: p)
                                            .frame(width: 150)
                                    }
                                }
                            }
                            .padding(.horizontal)
                        }
                    }
                    .padding(.vertical, 8)
                }
            }
            .navigationTitle("Home")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    ThemeToggle() // ← Top-right button to switch Light/Dark
                }
            }
        }
    }
}

struct CardView: View {
    @EnvironmentObject private var vm: PokemonViewModel
    let pokemon: Pokemon

    private var isFavorite: Bool { vm.favorites.contains(pokemon.id) }

    var body: some View {
        ZStack(alignment: .topTrailing) {
            VStack(spacing: 8) {
                Image(pokemon.images.first ?? "")
                    .resizable()
                    .scaledToFit()
                    .frame(height: 110)
                    .cornerRadius(8)

                Text(pokemon.name)
                    .font(.headline)
                    .lineLimit(1)
            }
            .padding(8)
            .background(Color(.systemBackground)) // adapts to light/dark
            .cornerRadius(12)
            .shadow(radius: 3)

            Button {
                vm.toggleFavorite(pokemon.id)
            } label: {
                Image(systemName: isFavorite ? "heart.fill" : "heart")
                    .font(.system(size: 16))
                    .foregroundColor(isFavorite ? .red : .primary)
                    .padding(6)
                    .background(Color(.secondarySystemBackground))
                    .clipShape(Circle())
            }
            .offset(x: -8, y: 8)
        }
    }
}

// MARK: - Theme Toggle Button
struct ThemeToggle: View {
    @EnvironmentObject var themeManager: ThemeManager

    var body: some View {
        Button {
            withAnimation {
                themeManager.isDarkMode.toggle()
            }
        } label: {
            Image(systemName: themeManager.isDarkMode ? "sun.max.fill" : "moon.fill")
                .font(.title2)
        }
        .accessibilityLabel(Text("Toggle theme"))
    }
}

struct HomePage_Previews: PreviewProvider {
    static var previews: some View {
        HomePage()
            .environmentObject(PokemonViewModel())
            .environmentObject(ThemeManager()) // ← required for ThemeToggle
    }
}
