//
//  WelcomeView.swift
//  Pokemon App
//
//  Created by David Santoso  on 5/8/25.
//

import SwiftUI

struct WelcomeView: View {
    @Binding var isPresented: Bool
    @Environment(\.colorScheme) private var scheme
    @State private var fadeIn = false
    @State private var showInfo = false

    // Switch logo by theme
    private var logoName: String {
        scheme == .dark ? "dark_logo" : "app_logo"
    }

    var body: some View {
        ZStack {
            LinearGradient(colors: [.blue.opacity(0.3), .red.opacity(0.3)],
                           startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()

            VStack(spacing: 24) {
                // Top buttons
                HStack {
                    Button { showInfo.toggle() } label: {
                        Image(systemName: "info.circle")
                            .font(.title)
                            .foregroundColor(scheme == .dark ? .white : .black)
                            .padding()
                    }
                    Spacer()
                    ThemeToggle()
                        .padding(.trailing, 8)
                }
                .frame(maxWidth: .infinity)

                Spacer()

                // Theme-aware logo with a soft crossfade
                Image(logoName)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 160, height: 160)
                    .opacity(fadeIn ? 1 : 0)
                    .id(logoName) // force reload when name changes
                    .transition(.opacity)
                    .animation(.easeInOut(duration: 0.25), value: logoName)

                Text("Pokémon Explorer")
                    .font(.largeTitle.bold())
                    .foregroundColor(scheme == .dark ? .white : .primary)
                    .opacity(fadeIn ? 1 : 0)

                Text("Browse & favorite your Gen-1 Pokémon")
                    .font(.headline)
                    .foregroundColor(.secondary)
                    .opacity(fadeIn ? 1 : 0)

                Button {
                    isPresented = false
                } label: {
                    Text("Get Started")
                        .bold()
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12))
                }
                .padding(.horizontal, 32)
                .opacity(fadeIn ? 1 : 0)

                Spacer()
            }
            .padding()
        }
        .onAppear {
            withAnimation(.easeIn(duration: 0.6)) { fadeIn = true }
        }
        .alert("Student Info", isPresented: $showInfo) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("""
                 Name: David Santoso
                 Student ID: S3824107
                 Course: COSC3062 COSC3063 IOS Development
                 """)
        }
    }
}

struct WelcomeView_Previews: PreviewProvider {
    @State static var show = true
    static var previews: some View {
        WelcomeView(isPresented: $show)
            .preferredColorScheme(.dark)
    }
}
