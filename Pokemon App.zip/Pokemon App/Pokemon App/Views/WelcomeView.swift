//
//  WelcomeView.swift
//  Pokemon App
//
//  Created by David Santoso  on 5/8/25.
//

import SwiftUI

struct WelcomeView: View {
    @Binding var isPresented: Bool      // ← binds to a @State in your App

    @State private var showInfo = false
    @State private var animateIn = false

    var body: some View {
        ZStack {

            VStack(spacing: 24) {
                Image("app_logo")   // ← name of your asset
                  .resizable().scaledToFit()
                  .frame(width: 150, height: 150)
                  .opacity(animateIn ? 1 : 0)
                  .offset(y: animateIn ? 0 : -20)

                Text("PokeBrowse")
                  .font(.largeTitle.bold())
                  .opacity(animateIn ? 1 : 0)
                  .offset(y: animateIn ? 0 : -20)

                Text("Discover Kanto’s Finest")
                  .font(.headline)
                  .opacity(animateIn ? 1 : 0)
                  .offset(y: animateIn ? 0 : -20)

                Button("Get Started") {
                    withAnimation { isPresented = false }
                }
                .buttonStyle(.borderedProminent)
                .font(.headline)
                .opacity(animateIn ? 1 : 0)
                .offset(y: animateIn ? 0 : -20)
            }
            .onAppear {
                withAnimation(.easeOut(duration: 1)) {
                    animateIn = true
                }
            }
            .overlay(
                Button { showInfo = true } label: {
                    Image(systemName: "info.circle.fill")
                      .font(.title)
                      .padding()
                },
                alignment: .topTrailing
            )
            .alert("About Me", isPresented: $showInfo) {
                Button("OK", role: .cancel) { }
            } message: {
                Text("""
                     Name: David Santoso
                     ID: s3824107
                     Program: iOS Development
                     """)
            }
        }
    }
}
struct WelcomeView_Previews: PreviewProvider {
    @State static var show = true
    static var previews: some View {
        WelcomeView(isPresented: $show)
    }
}
