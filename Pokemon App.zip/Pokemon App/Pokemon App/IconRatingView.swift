import SwiftUI

struct IconRatingView: View {
    let value: Double          // e.g. 3.2
    let maxRating: Int         // usually 5
    let filledImage: String    // e.g. "flame.fill" or "star.fill"
    let emptyImage: String     // e.g. "flame" or "star"
    let filledColor: Color
    var spacing: CGFloat = 4
    var iconSize: CGFloat = 20

    private var clamped: Double {
        min(max(value, 0), Double(maxRating))
    }

    var body: some View {
        ZStack(alignment: .leading) {
            // Background row: empty icons
            HStack(spacing: spacing) {
                ForEach(0..<maxRating, id: \.self) { _ in
                    Image(systemName: emptyImage)
                        .resizable()
                        .scaledToFit()
                        .frame(width: iconSize, height: iconSize)
                        .foregroundColor(.gray)
                }
            }

            // Foreground row: filled icons masked left-to-right
            HStack(spacing: spacing) {
                ForEach(0..<maxRating, id: \.self) { _ in
                    Image(systemName: filledImage)
                        .resizable()
                        .scaledToFit()
                        .frame(width: iconSize, height: iconSize)
                        .foregroundColor(filledColor)
                }
            }
            .mask(
                GeometryReader { geometry in
                    let totalWidth = geometry.size.width
                    Rectangle()
                        .frame(width: totalWidth * CGFloat(clamped / Double(maxRating)))
                        .alignmentGuide(.leading) { _ in 0 }
                }
            )
        }
        .frame(height: iconSize)
    }
}
