//
//  ThemeToggle.swift
//  Pokemon App
//
//  Created by David Santoso  on 8/8/25.
//

import SwiftUI

struct ThemeToggle: View {
    @AppStorage("isDarkMode") private var isDarkMode = false
    
    var body: some View {
        Button {
            isDarkMode.toggle()
        } label: {
            Image(systemName: isDarkMode ? "sun.max.fill" : "moon.fill")
                .imageScale(.large)
        }
        .accessibilityLabel("Toggle Dark Mode")
    }
}
