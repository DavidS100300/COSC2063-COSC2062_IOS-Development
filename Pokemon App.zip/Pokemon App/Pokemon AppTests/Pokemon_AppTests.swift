//
//  Pokemon_AppTests.swift
//  Pokemon AppTests
//
//  Created by David Santoso  on 5/8/25.
//

import Testing

struct Pokemon_AppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
